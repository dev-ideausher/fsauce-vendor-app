import 'package:get/get.dart';

class AddItemDetailsController extends GetxController {
  //TODO: Implement AddItemDetailsController

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
