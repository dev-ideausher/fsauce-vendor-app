import 'package:get/get.dart';

class ScanHistoryController extends GetxController {
  //TODO: Implement ScanHistoryController

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
