import 'package:get/get.dart';

class NotificationsController extends GetxController {
  //TODO: Implement NotificationsController

  RxList<String> notifications = <String>[].obs;
}
