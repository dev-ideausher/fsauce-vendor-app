import 'package:get/get.dart';

class LoyaltyCardPreviewController extends GetxController {
  //TODO: Implement LoyaltyCardPreviewController

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
